function testing(aswdd,adfdf){ console.log(aswdd)};
