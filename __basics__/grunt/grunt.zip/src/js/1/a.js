function testingab(aswdd,adfdf){ console.log(aswdd)};
